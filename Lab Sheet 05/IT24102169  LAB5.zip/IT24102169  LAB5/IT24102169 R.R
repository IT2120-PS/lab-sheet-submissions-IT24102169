setwd("C:\\Users\\hP\\Desktop\\IT24102169  LAB5")
delivery_times <- read.table("Exercise - Lab 05.txt", header = TRUE)
print(delivery_times)
breaks <- seq(20, 70, by = 6)
hist(delivery_times$Delivery_Time_(minutes),
     breaks = breaks,
     right = FALSE,
     main = "Histogram of Delivery Times",
     xlab = "Delivery Time (minutes)",
     ylab = "Frequency")
hist_data <- hist(delivery_times$Delivery_Time_(minutes),
                  breaks = breaks,
                  right = FALSE,
                  plot = FALSE)
hist(delivery_times$`Delivery_Time_(minutes)`,
     breaks = breaks,
     right = FALSE,
     main = "Histogram of Delivery Times",
     xlab = "Delivery Time (minutes)",
     ylab = "Frequency")
colnames(delivery_times) <- c("Delivery_Time")
hist(delivery_times$Delivery_Time,
     breaks = breaks,
     right = FALSE,
     col = "skyblue",
     main = "Histogram of Delivery Times",
     xlab = "Delivery Time (minutes)",
     ylab = "Frequency",
     border = "black")
hist_data <- hist(delivery_times$Delivery_Time_(minutes),
                  breaks = breaks,
                  right = FALSE,
                  plot = FALSE)
hist_data <- hist(delivery_times$Delivery_Time,
                  breaks = breaks,
                  right = FALSE,
                  plot = FALSE)
cum_freq <- cumsum(hist_data$counts)
hist(delivery_times$Delivery_Time,
     breaks = breaks,
     right = FALSE,
     main = "Histogram of Delivery Times",
     xlab = "Delivery Time (minutes)",
     ylab = "Frequency")
cum_freq <- cumsum(hist_data$counts)
plot(hist_data$breaks[-1], cum_freq,
     type = "o",
     main = "Cumulative Frequency Polygon (Ogive)",
     xlab = "Delivery Time (minutes)",
     ylab = "Cumulative Frequency")
setwd("C:\\Users\\Shaheen Nazar\\Desktop\\Lab5_IT24101993")
hist(delivery_times$Delivery_Time,
     breaks = breaks,
     right = FALSE,
     main = "Histogram of Delivery Times",
     xlab = "Delivery Time (minutes)",
     ylab = "Frequency")
hist_data <- hist(delivery_times$Delivery_Time,
                  breaks = breaks,
                  right = FALSE,
                  plot = FALSE)
cum_freq <- cumsum(hist_data$counts)
plot(hist_data$breaks[-1], cum_freq,
     type = "o",
     main = "Cumulative Frequency Polygon (Ogive)",
     xlab = "Delivery Time (minutes)",
     ylab = "Cumulative Frequency")

